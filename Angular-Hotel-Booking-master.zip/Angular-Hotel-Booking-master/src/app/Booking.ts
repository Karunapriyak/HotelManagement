export interface Booking {
    hotel_id : number;
    hotel_name: string;
    check_in_date: string;
    check_out_date : string;
    no_of_guest : number;
    no_of_rooms : number;
    user_name: string;
    booking_date: string;
    booking_status: string;
    
}