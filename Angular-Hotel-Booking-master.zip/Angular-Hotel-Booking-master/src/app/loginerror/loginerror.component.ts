import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loginerror',
  templateUrl: './loginerror.component.html',
  styleUrls: ['./loginerror.component.scss']
})
export class LoginerrorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
