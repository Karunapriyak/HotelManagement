import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookingfailure',
  templateUrl: './bookingfailure.component.html',
  styleUrls: ['./bookingfailure.component.scss']
})
export class BookingfailureComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
