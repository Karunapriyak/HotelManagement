import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookingsuccess',
  templateUrl: './bookingsuccess.component.html',
  styleUrls: ['./bookingsuccess.component.scss']
})
export class BookingsuccessComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
